require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const port = process.env.PORT || 3019;

// Middleware
app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));

// Mongo Connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});
const db = mongoose.connection;
db.once('open', () => console.log("MongoDB connection successful"));
db.on('error', err => console.error("MongoDB connection error:", err));

// Mongoose Schema
const userSchema = new mongoose.Schema({
  regd_no: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, match: /.+\@.+\..+/ },
  branch: { type: String, required: true, enum: ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL'] }
});
const Users = mongoose.model("Users", userSchema);

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'form.html'));
});

app.post('/post', async (req, res) => {
  try {
    const { regd_no, name, email, branch } = req.body;

    const exists = await Users.findOne({ regd_no });
    if (exists) {
      return res.status(400).send("A user with this Registration Number already exists.");
    }

    const user = new Users({ regd_no, name, email, branch });
    await user.save();
    res.send("Form Submission Successful");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});

// Server
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});