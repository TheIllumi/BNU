# ClassSyncAI
Final Project of Artificial Intelligence - ClassSync AI
