from timetable_optimizer import *

# Load data
courses_df, rooms_df = load_course_and_room_data("Courses_Processed.csv", "Rooms.csv")
sessions_df = create_sessions_from_courses(courses_df)
slots = generate_time_slots(CONFIG)

# Run GA
population, all_forced, all_missed = generate_population(30, sessions_df, slots, rooms_df)
best_schedule, best_score, history = optimize(
    population, slots, rooms_df['Rooms'].tolist(), generations=50, elite_size=2, mutation_rate=0.1
)

# Save forced placements
with open("forced_placements_log.txt", "w", encoding="utf-8") as f:
    for log in all_forced:
        label = "[RELAXED]" if log.get("Relaxed") else "[FORCED]"
        f.write(f"{log['Course']} → {log['Day']} at {log['Start']} in {log['Room']} [FORCED]\n")

# Save missed sessions
with open("missed_sessions_log.txt", "w", encoding="utf-8") as f:
    for course in all_missed:
        f.write(f"[!] Could not place: {course['Course']} – Reason: {course['Reason']}\n")

# Optional: Print schedule by day
format_schedule_by_day(best_schedule)

# Check for missed sessions
scheduled_keys = set(best_schedule['Course_Key'])
expected_keys = set(sessions_df['Course_Key'])

missing_keys = expected_keys - scheduled_keys

if missing_keys:
    print(f"\n❌ {len(missing_keys)} course sessions were NOT scheduled:")
    for key in sorted(missing_keys):
        print(f"  - {key}")
else:
    print("\n✅ All course sessions were successfully scheduled!")

# Save missing course keys to a file
with open("unscheduled_courses.txt", "w", encoding="utf-8") as f:
    for key in sorted(missing_keys):
        f.write(f"{key}\n")

from collections import Counter
problem_courses = [key.split(" - ")[-1] for key in missing_keys]  # Extract sections
Counter(problem_courses).most_common()

print("\n📊 Most common missing sections or groups:")
for section, count in Counter(problem_courses).most_common():
    print(f"  - {section}: {count} sessions missed")

overlong = check_long_sessions(best_schedule)
if overlong:
    print("\n[!] Detected sessions exceeding 3 hours:")
    for course, day, start, end in overlong:
        print(f"  - {course} on {day} from {start} to {end}")

label = "[FORCED]" if not log.get("Relaxed") else "[RELAXED]"
f.write(f"{log['Course']} → {log['Day']} at {log['Start']} in {log['Room']} {label}\n")

# Optional: Count how often each course appears (if needed)
# print(sessions_df['Course_Key'].value_counts())