import pandas as pd
import random
from tqdm import tqdm
from datetime import time, datetime, timedelta
VERBOSE = False

# ==============================
# Configuration Settings
# ==============================
CONFIG = {
    "working_days": ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    "daily_start": time(8, 0),
    "daily_end": time(18, 30),
    "slot_duration_minutes": 90,
    "vc_slot_days": ['Monday', 'Tuesday'],
    "vc_slot_time": (time(12, 30), time(14, 0)),
    "lab_duration_slots": 2,
    "disallow_weekends": True
}

# ==============================
# Function: Load and clean data
# ==============================
def load_course_and_room_data(course_path, room_path):
    courses_df = pd.read_csv(course_path)
    rooms_df = pd.read_csv(room_path)

    courses_df.columns = courses_df.columns.str.strip()
    rooms_df.columns = rooms_df.columns.str.strip()

    courses_df['Course_Key'] = (
        courses_df['Course Name'].str.strip() + " - " +
        courses_df['Program'].str.strip() + courses_df['Section'].str.strip()
    )
    courses_df['Is_Lab'] = courses_df['Course Name'].str.contains('Lab', case=False)

    return courses_df, rooms_df

# ==============================
# Function: Generate time slots
# ==============================
def generate_time_slots(config):
    slots = []
    start_dt = datetime.combine(datetime.today(), config["daily_start"])
    end_dt = datetime.combine(datetime.today(), config["daily_end"])
    delta = timedelta(minutes=config["slot_duration_minutes"])

    while start_dt + delta <= end_dt:
        slot_start = start_dt.time()
        slot_end = (start_dt + delta).time()
        slots.append((slot_start, slot_end))
        start_dt += delta

    filtered_slots = []
    vc_start, vc_end = config["vc_slot_time"]
    for day in config["working_days"]:
        for start, end in slots:
            if day in config["vc_slot_days"] and vc_start <= start < vc_end:
                continue
            filtered_slots.append((day, start, end))

    return filtered_slots

# ==============================
# Function: Create session entries
# ==============================
def create_sessions_from_courses(courses_df):
    sessions = []
    for _, row in courses_df.iterrows():
        for _ in range(1 if row['Is_Lab'] else 2):
            sessions.append({
                "Course_Key": row['Course_Key'],
                "Course_Name": row['Course Name'],
                "Instructor": row['Instructor'],
                "Section": row['Section'],
                "Is_Lab": row['Is_Lab'],
                "Duration_Slots": 2 if row['Is_Lab'] else 1
            })
    return pd.DataFrame(sessions)

# ==============================
# Function: Generate a schedule
# ==============================
def generate_individual(sessions_df, available_slots, rooms_df, max_trials=500, show_progress=False):
    schedule = []
    forced_log = []
    missed_sessions = []

    lab_rooms = rooms_df[rooms_df['Type'].str.lower() == 'lab']['Rooms'].tolist()
    theory_rooms = rooms_df[rooms_df['Type'].str.lower() == 'theory']['Rooms'].tolist()

    # 🧠 Prioritize CS2 and CS4 + Labs
    priority_sections = ['CS2', 'CS4']
    sessions_df['Priority'] = sessions_df['Section'].apply(lambda s: any(p in s for p in priority_sections))
    sessions_df = sessions_df.sort_values(by=['Priority', 'Is_Lab'], ascending=[False, False])

    iterator = tqdm(sessions_df.iterrows(), total=len(sessions_df), desc="📅 Placing Sessions", unit="session") if show_progress else sessions_df.iterrows()

    for _, session in iterator:
        placed = False
        trials = 0

        while not placed and trials < max_trials:
            trials += 1
            day, start, _ = random.choice(available_slots)
            is_lab = session["Is_Lab"]
            room = random.choice(lab_rooms if is_lab else theory_rooms)

            if is_lab:
                idx = next((i for i, s in enumerate(available_slots) if s[0] == day and s[1] == start), -1)
                if idx == -1 or idx + 1 >= len(available_slots): continue
                next_slot = available_slots[idx + 1]
                if next_slot[0] != day: continue
                end_time = next_slot[2]
                if end_time > CONFIG["daily_end"]: continue
            else:
                end_time = (datetime.combine(datetime.today(), start) + timedelta(minutes=90)).time()

            conflict = any(
                s["Weekday"] == day and
                (s["Room"] == room or s["Instructor"] == session["Instructor"] or s["Section"] == session["Section"]) and
                not (s["End_Time"] <= start.strftime('%H:%M') or s["Start_Time"] >= end_time.strftime('%H:%M'))
                for s in schedule
            )
            if conflict: continue

            schedule.append({
                **session,
                "Weekday": day,
                "Start_Time": start.strftime('%H:%M'),
                "End_Time": end_time.strftime('%H:%M'),
                "Room": room
            })
            placed = True

        # 🔁 Fallback for labs
        if not placed and session["Is_Lab"]:
            for _ in range(100):
                day, start, _ = random.choice(available_slots)
                room = random.choice(lab_rooms)
                idx = next((i for i, s in enumerate(available_slots) if s[0] == day and s[1] == start), -1)
                if idx == -1 or idx + 1 >= len(available_slots): continue
                next_slot = available_slots[idx + 1]
                if next_slot[0] != day: continue
                end_time = next_slot[2]
                if end_time > CONFIG["daily_end"]: continue

                conflict = any(
                    s["Weekday"] == day and
                    (s["Room"] == room or s["Instructor"] == session["Instructor"] or s["Section"] == session["Section"]) and
                    not (s["End_Time"] <= start.strftime('%H:%M') or s["Start_Time"] >= end_time.strftime('%H:%M'))
                    for s in schedule
                )
                if conflict: continue

                schedule.append({
                    **session,
                    "Weekday": day,
                    "Start_Time": start.strftime('%H:%M'),
                    "End_Time": end_time.strftime('%H:%M'),
                    "Room": room,
                    "Forced": True,
                    "Adjusted_Duration": 1
                })

                forced_log.append({
                    "Course": session['Course_Key'],
                    "Day": day,
                    "Start": start.strftime('%H:%M'),
                    "Room": room
                })
                placed = True
                break

        # 🔁 Fallback for theory (full constraint)
        if not placed and not session["Is_Lab"]:
            for _ in range(100):
                day, start, _ = random.choice(available_slots)
                room = random.choice(theory_rooms)
                end_time = (datetime.combine(datetime.today(), start) + timedelta(minutes=90)).time()
                if end_time > CONFIG["daily_end"]: continue

                conflict = any(
                    s["Weekday"] == day and
                    (s["Room"] == room or s["Instructor"] == session["Instructor"] or s["Section"] == session["Section"]) and
                    not (s["End_Time"] <= start.strftime('%H:%M') or s["Start_Time"] >= end_time.strftime('%H:%M'))
                    for s in schedule
                )
                if conflict: continue

                schedule.append({
                    **session,
                    "Weekday": day,
                    "Start_Time": start.strftime('%H:%M'),
                    "End_Time": end_time.strftime('%H:%M'),
                    "Room": room,
                    "Forced": True,
                    "Adjusted_Duration": 1
                })

                forced_log.append({
                    "Course": session['Course_Key'],
                    "Day": day,
                    "Start": start.strftime('%H:%M'),
                    "Room": room
                })
                placed = True
                break

        # 🔁 Relaxed fallback for theory (instructor-only conflict)
        if not placed and not session["Is_Lab"]:
            for _ in range(100):
                day, start, _ = random.choice(available_slots)
                room = random.choice(theory_rooms)
                end_time = (datetime.combine(datetime.today(), start) + timedelta(minutes=90)).time()
                if end_time > CONFIG["daily_end"]: continue

                conflict = any(
                    s["Weekday"] == day and
                    s["Instructor"] == session["Instructor"] and
                    not (s["End_Time"] <= start.strftime('%H:%M') or s["Start_Time"] >= end_time.strftime('%H:%M'))
                    for s in schedule
                )
                if conflict: continue

                schedule.append({
                    **session,
                    "Weekday": day,
                    "Start_Time": start.strftime('%H:%M'),
                    "End_Time": end_time.strftime('%H:%M'),
                    "Room": room,
                    "Forced": True,
                    "Adjusted_Duration": 1,
                    "Relaxed": True
                })

                forced_log.append({
                    "Course": session['Course_Key'],
                    "Day": day,
                    "Start": start.strftime('%H:%M'),
                    "Room": room,
                    "Relaxed": True
                })
                placed = True
                break

        # ❌ Still not placed
        if not placed:
            missed_sessions.append({
                "Course": session["Course_Key"],
                "Reason": "No conflict-free room/slot found"
            })

    # ✅ Final retry for missed theory sessions
    for session in missed_sessions[:]:
        if session["Course"].endswith("Lab"):
            continue

        for _ in range(50):
            day, start, _ = random.choice(available_slots)
            room = random.choice(theory_rooms)
            end_time = (datetime.combine(datetime.today(), start) + timedelta(minutes=90)).time()
            if end_time > CONFIG["daily_end"]: continue

            conflict = any(
                s["Weekday"] == day and
                s["Instructor"] == session["Course"].split(" - ")[0] and
                not (s["End_Time"] <= start.strftime('%H:%M') or s["Start_Time"] >= end_time.strftime('%H:%M'))
                for s in schedule
            )
            if conflict: continue

            schedule.append({
                "Course_Key": session["Course"],
                "Weekday": day,
                "Start_Time": start.strftime('%H:%M'),
                "End_Time": end_time.strftime('%H:%M'),
                "Room": room,
                "Forced": True,
                "Adjusted_Duration": 1,
                "Relaxed": True
            })

            forced_log.append({
                "Course": session['Course'],
                "Day": day,
                "Start": start.strftime('%H:%M'),
                "Room": room,
                "Relaxed": True
            })
            missed_sessions.remove(session)
            break

    return pd.DataFrame(schedule), forced_log, missed_sessions

# ==============================
# Function: Generate population
# ==============================
def generate_population(pop_size, sessions_df, available_slots, rooms_df, show_progress=False):
    population = []
    all_forced = []
    all_missed = []

    for _ in range(pop_size):
        schedule, forced_log, missed_sessions = generate_individual(
            sessions_df, available_slots, rooms_df, show_progress=show_progress
        )
        population.append(schedule)
        all_forced.extend(forced_log)
        all_missed.extend(missed_sessions)

    return population, all_forced, all_missed

# ==============================
# Function: Calculate fitness
# ==============================
def calculate_fitness(individual):
    penalty = 0
    individual['Start_Time_obj'] = pd.to_datetime(individual['Start_Time'], format="%H:%M").dt.time
    individual['End_Time_obj'] = pd.to_datetime(individual['End_Time'], format="%H:%M").dt.time

    for i, row in individual.iterrows():
        overlapping = individual[
            (individual['Weekday'] == row['Weekday']) &
            (individual.index != i) &
            (individual['Start_Time_obj'] < row['End_Time_obj']) &
            (individual['End_Time_obj'] > row['Start_Time_obj'])
        ]

        penalty += (
            len(overlapping[overlapping['Instructor'] == row['Instructor']]) * 10 +
            len(overlapping[overlapping['Room'] == row['Room']]) * 10 +
            len(overlapping[overlapping['Section'] == row['Section']]) * 10
        )

        # Extra penalty for forced fallback labs
        if 'Forced' in row and row['Forced']:
            penalty += 5

    return max(1, 1000 - penalty)

# ==============================
# Function: Crossover
# ==============================
def crossover(parent1, parent2):
    split = len(parent1) // 2

    def create_child(p1, p2):
        child = pd.concat([p1.iloc[:split], p2.iloc[split:]], ignore_index=True)
        child = child.drop_duplicates(subset=["Course_Key"], keep='first')
        if child.empty:
            return p1.copy().reset_index(drop=True)
        return child.reset_index(drop=True)

    return create_child(parent1, parent2), create_child(parent2, parent1)

# ==============================
# Function: Mutate
# ==============================
def mutate(individual, available_slots, room_list, mutation_rate=0.1):
    if random.random() >= mutation_rate:
        return individual

    idx = random.randint(0, len(individual) - 1)
    session = individual.loc[idx]
    is_lab = session['Is_Lab']
    trials = 0

    while trials < 100:
        trials += 1
        day, start_time, _ = random.choice(available_slots)

        # Try to find consecutive 2-slot lab placement
        if is_lab:
            i = next((i for i, s in enumerate(available_slots) if s[0] == day and s[1] == start_time), -1)
            if i == -1 or i + 1 >= len(available_slots): continue
            next_slot = available_slots[i + 1]
            if next_slot[0] != day: continue
            end_time = next_slot[2]
        else:
            end_time = start_time

        individual.at[idx, 'Weekday'] = day
        individual.at[idx, 'Start_Time'] = start_time.strftime('%H:%M')
        individual.at[idx, 'End_Time'] = end_time.strftime('%H:%M')
        individual.at[idx, 'Room'] = random.choice(room_list)

        # Remove "Forced" if lab is now valid
        if 'Forced' in individual.columns:
            individual.at[idx, 'Forced'] = False
        if 'Adjusted_Duration' in individual.columns:
            individual.at[idx, 'Adjusted_Duration'] = None
        break

    return individual

# ==============================
# Function: Optimize
# ==============================
def optimize(population, available_slots, room_list, generations=50, elite_size=2, mutation_rate=0.1):
    best_fitness_history = []

    bar_format = "{l_bar}{bar} | {n_fmt}/{total_fmt} Gen | Best: {postfix[best]} | ETA: {remaining}"
    progress_bar = tqdm(
        range(generations),
        desc="🧬 Optimizing",
        unit="gen",
        ncols=80,
        dynamic_ncols=False
    )

    for gen in progress_bar:
        fitness_scores = [calculate_fitness(ind) for ind in population]
        best_fitness = max(fitness_scores)
        best_fitness_history.append(best_fitness)

        # 🔁 Update progress bar with current best score
        progress_bar.set_postfix_str(f"Best: {best_fitness}")


        elite_indices = sorted(range(len(fitness_scores)), key=lambda i: fitness_scores[i], reverse=True)[:elite_size]
        new_population = [population[i].copy() for i in elite_indices]

        while len(new_population) < len(population):
            parent1, parent2 = random.sample(population, 2)
            child1, child2 = crossover(parent1, parent2)
            new_population.append(mutate(child1, available_slots, room_list, mutation_rate))
            if len(new_population) < len(population):
                new_population.append(mutate(child2, available_slots, room_list, mutation_rate))

        population = new_population

    final_scores = [calculate_fitness(ind) for ind in population]
    best_index = final_scores.index(max(final_scores))
    return population[best_index], final_scores[best_index], best_fitness_history

# ==============================
# Function: Format Schedule
# ==============================
def format_schedule_by_day(schedule_df):
    days = schedule_df['Weekday'].unique()

    for day in days:
        print(f"\n📅 {day}")
        day_df = schedule_df[schedule_df['Weekday'] == day]
        display_cols = ['Start_Time', 'End_Time', 'Course_Key', 'Instructor', 'Section', 'Room']
        print(day_df[display_cols].sort_values(by='Start_Time').to_string(index=False))


# ==============================
# Function: Check 3+ hour Sessions
# ==============================
def check_long_sessions(df):
    from datetime import datetime
    long_sessions = []
    for _, row in df.iterrows():
        start = datetime.strptime(row["Start_Time"], "%H:%M")
        end = datetime.strptime(row["End_Time"], "%H:%M")
        duration = (end - start).seconds / 60
        if duration > 180:
            long_sessions.append((row["Course_Key"], row["Weekday"], row["Start_Time"], row["End_Time"]))
    return long_sessions