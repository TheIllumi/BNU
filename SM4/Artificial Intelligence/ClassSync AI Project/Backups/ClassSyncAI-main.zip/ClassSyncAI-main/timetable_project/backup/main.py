import pandas as pd
import random
from datetime import time, datetime, timedelta

# ==============================
# Configuration Settings
# ==============================
CONFIG = {
    "working_days": ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    "daily_start": time(8, 0),
    "daily_end": time(15, 30),
    "slot_duration_minutes": 90,
    "vc_slot_days": ['Monday', 'Tuesday'],
    "vc_slot_time": (time(12, 30), time(14, 0)),
    "lab_duration_slots": 2,  # Lab classes span 2 consecutive slots
    "disallow_weekends": True
}

# ==============================
# Function: Load and clean data
# ==============================
def load_course_and_room_data(course_path, room_path):
    courses_df = pd.read_csv(course_path)
    rooms_df = pd.read_csv(room_path)

    courses_df.columns = courses_df.columns.str.strip()
    rooms_df.columns = rooms_df.columns.str.strip()

    courses_df['Course_Key'] = (
        courses_df['Course Name'].str.strip() + " - " +
        courses_df['Program'].str.strip() + courses_df['Section'].str.strip()
    )
    courses_df['Is_Lab'] = courses_df['Course Name'].str.contains('Lab', case=False)

    return courses_df, rooms_df

# ==============================
# Function: Generate time slots
# ==============================
def generate_time_slots(config):
    """
    Generate valid time slots for scheduling excluding VC hours.
    """
    slots = []
    start_dt = datetime.combine(datetime.today(), config["daily_start"])
    end_dt = datetime.combine(datetime.today(), config["daily_end"])
    delta = timedelta(minutes=config["slot_duration_minutes"])

    # Generate raw slots
    while start_dt + delta <= end_dt:
        slot_start = start_dt.time()
        slot_end = (start_dt + delta).time()
        slots.append((slot_start, slot_end))
        start_dt += delta

    # Filter VC slots per working day
    filtered_slots = []
    vc_start, vc_end = config["vc_slot_time"]
    for day in config["working_days"]:
        for start, end in slots:
            if day in config["vc_slot_days"] and vc_start <= start < vc_end:
                continue  # Skip VC slot
            filtered_slots.append((day, start, end))

    return filtered_slots

# ==============================
# Load and preview data
# ==============================
COURSE_CSV = "Courses_Processed.csv"
ROOM_CSV = "Rooms.csv"

courses_df, room_list = load_course_and_room_data(COURSE_CSV, ROOM_CSV)
available_slots = generate_time_slots(CONFIG)

# Preview data
print("Sample Courses:\n", courses_df.head())
print("\nAvailable Rooms:\n", room_list[:5])
print("\nSample Time Slots:")
for slot in available_slots[:5]:  # Display only first few slots
    print(slot)

# ============================================
# Function: Create session entries from courses
# ============================================
def create_sessions_from_courses(courses_df, config):
    """
    Break each course into individual session blocks depending on type (lab/regular).
    Returns a DataFrame of session entries.
    """
    sessions = []

    for _, row in courses_df.iterrows():
        session_base = {
            "Course_Key": row['Course_Key'],
            "Course_Name": row['Course Name'],
            "Instructor": row['Instructor'],
            "Section": row['Section'],
            "Is_Lab": row['Is_Lab']
        }

        if row['Is_Lab']:
            # 1 lab session occupying multiple slots
            session_base["Duration_Slots"] = config["lab_duration_slots"]
            sessions.append(session_base)
        else:
            # 2 regular sessions
            for _ in range(2):
                session = session_base.copy()
                session["Duration_Slots"] = 1
                sessions.append(session)

    return pd.DataFrame(sessions)

# ============================================
# Function: Generate a random feasible schedule
# ============================================
def generate_individual(sessions_df, available_slots, rooms_df, max_trials=500):
    """
    Generate a random, non-overlapping schedule for all sessions.
    Uses room type (Lab/Theory) and avoids room/instructor/section conflicts.
    """
    schedule = []

    # Pre-filter room lists
    lab_rooms = rooms_df[rooms_df['Type'].str.lower() == 'lab']['Rooms'].tolist()
    theory_rooms = rooms_df[rooms_df['Type'].str.lower() == 'theory']['Rooms'].tolist()

    for _, session in sessions_df.iterrows():
        placed = False
        trials = 0

        while not placed and trials < max_trials:
            trials += 1
            day, start, end = random.choice(available_slots)

            # Get appropriate room list
            possible_rooms = lab_rooms if session["Is_Lab"] else theory_rooms
            room = random.choice(possible_rooms)
            end_time = end

            # Handle lab sessions needing 2 consecutive slots
            if session["Duration_Slots"] == 2:
                idx = next((i for i, s in enumerate(available_slots) if s[0] == day and s[1] == start), -1)
                if idx == -1 or idx + 1 >= len(available_slots):
                    continue
                next_slot = available_slots[idx + 1]
                if next_slot[0] != day:
                    continue
                end_time = next_slot[2]

            # Check conflicts in current schedule
            conflict = any(
                s["Weekday"] == day and
                (
                    s["Room"] == room or
                    s["Instructor"] == session["Instructor"] or
                    s["Section"] == session["Section"]
                ) and not (
                    s["End_Time"] <= start.strftime('%H:%M') or
                    s["Start_Time"] >= end_time.strftime('%H:%M')
                )
                for s in schedule
            )

            if conflict:
                continue

            # No conflict → place session
            schedule.append({
                **session,
                "Weekday": day,
                "Start_Time": start.strftime('%H:%M'),
                "End_Time": end_time.strftime('%H:%M'),
                "Room": room
            })
            placed = True

        # Emergency fallback after max_trials (optional: can skip or force-place)
        if not placed:
            print(f"⚠️ Could not place: {session['Course_Key']}")

    return pd.DataFrame(schedule)

# ============================================
# Build sessions and generate one individual
# ============================================
sessions_df = create_sessions_from_courses(courses_df, CONFIG)
print("Sample sessions:\n", sessions_df.head(10))
print("\nTotal sessions:", len(sessions_df))

# Example of generating a schedule
best_schedule = generate_individual(sessions_df, available_slots, room_list)

print("✅ Unique course-keys:", best_schedule['Course_Key'].nunique())
print("✅ Total sessions:", len(best_schedule))
print("✅ Sections covered:", best_schedule['Section'].nunique())

# ========================================
# Generate one individual and preview
# ========================================
individual_schedule = generate_individual(sessions_df, available_slots, room_list)
print(individual_schedule.head(10))
print("\nTotal sessions scheduled:", len(individual_schedule))

# ========================================
# Function: Generate a population
# ========================================
def generate_population(pop_size, sessions_df, available_slots, rooms):
    """
    Create a list of individuals (schedules).
    """
    return [
        generate_individual(sessions_df, available_slots, rooms)
        for _ in range(pop_size)
    ]

# Generate initial population
population = generate_population(10, sessions_df, available_slots, room_list)

# Preview one individual
print("Sample individual:\n", population[0].head())
print(f"✅ Population size: {len(population)}")
print(f"✅ Total sessions in sample: {len(population[0])}")
print(f"✅ Unique course-keys: {population[0]['Course_Key'].nunique()}")
print(f"✅ Sections: {population[0]['Section'].nunique()}")

# ========================================
# Function: Fitness Evaluation
# ========================================
def calculate_fitness(individual):
    """
    Penalize instructor, room, or section conflicts.
    Higher score = better individual.
    """
    penalty = 0
    # Convert time strings to datetime.time for accurate comparisons
    individual['Start_Time_obj'] = pd.to_datetime(individual['Start_Time'], format="%H:%M").dt.time
    individual['End_Time_obj'] = pd.to_datetime(individual['End_Time'], format="%H:%M").dt.time

    for i, row in individual.iterrows():
        overlapping = individual[
            (individual['Weekday'] == row['Weekday']) &
            (individual.index != i) &
            (individual['Start_Time_obj'] < row['End_Time_obj']) &
            (individual['End_Time_obj'] > row['Start_Time_obj'])
        ]

        penalty += (
            len(overlapping[overlapping['Instructor'] == row['Instructor']]) * 10 +
            len(overlapping[overlapping['Room'] == row['Room']]) * 10 +
            len(overlapping[overlapping['Section'] == row['Section']]) * 10
        )

    return max(1, 1000 - penalty)  # Ensure score is always ≥ 1

# Fitness for first sample
sample = population[0]
fitness_score = calculate_fitness(sample)
print("Fitness Score:", fitness_score)

# ========================================
# Function: Tournament Selection
# ========================================
def selection(population, fitness_scores, tournament_size=3):
    """
    Select 2 individuals using tournament selection.
    """
    selected = []
    for _ in range(2):
        contenders = random.sample(list(zip(population, fitness_scores)), tournament_size)
        winner = max(contenders, key=lambda x: x[1])[0]
        selected.append(winner)
    return selected

# ========================================
# Function: Single-point Crossover
# ========================================
def crossover(parent1, parent2):
    """
    Perform single-point crossover and remove duplicates by Course_Key.
    """
    split = len(parent1) // 2

    def create_child(p1, p2):
        child = pd.concat([p1.iloc[:split], p2.iloc[split:]])
        child = child.drop_duplicates(subset=["Course_Key"], keep='first')
        return child if not child.empty else p1.copy()

    child1 = create_child(parent1, parent2).reset_index(drop=True)
    child2 = create_child(parent2, parent1).reset_index(drop=True)
    
    return child1, child2

# ========================================
# Function: Mutate a schedule
# ========================================
def mutate(individual, available_slots, room_list, mutation_rate=0.1):
    """
    Randomly change the slot and room for one session.
    """
    if random.random() < mutation_rate:
        idx = random.randint(0, len(individual) - 1)
        session = individual.loc[idx]
        is_lab = session['Is_Lab']
        duration_slots = session['Duration_Slots']
        trials = 0

        while trials < 100:
            new_slot = random.choice(available_slots)
            day, start_time, _ = new_slot
            trials += 1

            if is_lab:
                i = next((i for i, s in enumerate(available_slots) if s[0] == day and s[1] == start_time), -1)
                if i == -1 or i + 1 >= len(available_slots): continue
                next_slot = available_slots[i + 1]
                if next_slot[0] != day: continue
                end_time = next_slot[2]
            else:
                end_time = new_slot[2]

            # Apply mutation
            individual.at[idx, 'Weekday'] = day
            individual.at[idx, 'Start_Time'] = start_time.strftime('%H:%M')
            individual.at[idx, 'End_Time'] = end_time.strftime('%H:%M')
            individual.at[idx, 'Room'] = random.choice(room_list)
            break

    return individual

# ========================================
# Function: Genetic Algorithm Optimizer
# ========================================
def optimize(population, generations=100, elite_size=2, mutation_rate=0.1):
    """
    Evolve a population of schedules to minimize conflicts using a Genetic Algorithm.
    """
    best_fitness_history = []

    for gen in range(generations):
        fitness_scores = [calculate_fitness(ind) for ind in population]
        best_fitness = max(fitness_scores)
        best_fitness_history.append(best_fitness)

        print(f"📈 Generation {gen + 1}: Best Fitness = {best_fitness}")

        # Elitism: carry over best individuals unchanged
        elite_indices = sorted(range(len(fitness_scores)), key=lambda i: fitness_scores[i], reverse=True)[:elite_size]
        new_population = [population[i].copy() for i in elite_indices]

        # Generate rest of the new population
        while len(new_population) < len(population):
            parent1, parent2 = selection(population, fitness_scores)
            child1, child2 = crossover(parent1, parent2)
            new_population.append(mutate(child1, available_slots, room_list, mutation_rate))
            if len(new_population) < len(population):
                new_population.append(mutate(child2, available_slots, room_list, mutation_rate))

        population = new_population

    final_scores = [calculate_fitness(ind) for ind in population]
    best_index = final_scores.index(max(final_scores))
    return population[best_index], final_scores[best_index], best_fitness_history

# ========================================
# Run Optimization on Initial Population
# ========================================
best_schedule, best_score, fitness_history = optimize(
    population, generations=50, elite_size=2, mutation_rate=0.1
)

print(f"\n🏆 Best Fitness Achieved: {best_score}")
best_schedule.to_csv("optimized_timetable.csv", index=False)

# ========================================
# Validation and Fresh Dataset Handling
# ========================================
# Reload and clean full course dataset
courses_df = pd.read_csv("Courses_Processed.csv")
courses_df.columns = courses_df.columns.str.strip()
courses_df['Course_Key'] = courses_df['Course Name'] + " - " + courses_df['Program'] + courses_df['Section']
courses_df['Is_Lab'] = courses_df['Course Name'].str.contains('Lab', case=False)

print(f"\n📚 Total rows: {len(courses_df)}")
print(f"📚 Unique courses: {courses_df['Course Name'].nunique()}")
print(f"📚 Sections: {courses_df['Section'].nunique()}")
print(f"✅ Unique Course Keys: {courses_df['Course_Key'].nunique()}")

# Recreate sessions
def create_sessions_from_courses(courses_df):
    sessions = []
    for _, row in courses_df.iterrows():
        for _ in range(1 if row['Is_Lab'] else 2):
            sessions.append({
                "Course_Key": row['Course_Key'],
                "Course_Name": row['Course Name'],
                "Instructor": row['Instructor'],
                "Section": row['Section'],
                "Is_Lab": row['Is_Lab'],
                "Duration_Slots": 2 if row['Is_Lab'] else 1
            })
    return pd.DataFrame(sessions)

sessions_df = create_sessions_from_courses(courses_df)
print(f"\n✅ Total sessions generated: {len(sessions_df)}")
print("✅ Sample sessions:\n", sessions_df.head())

# Refresh slots and rooms
available_slots = generate_time_slots(CONFIG)
room_list = pd.read_csv("Rooms.csv")['Rooms'].tolist()

# Build new population and optimize again
population = generate_population(
    pop_size=30,
    sessions_df=sessions_df,
    available_slots=available_slots,
    rooms=room_list
)

best_schedule, best_score, fitness_history = optimize(
    population, generations=100, elite_size=2, mutation_rate=0.2
)

print(f"\n✅ Final Best Fitness: {best_score}")
print(f"✅ Unique Course Keys: {best_schedule['Course_Key'].nunique()}")
print(f"✅ Total Sessions Scheduled: {len(best_schedule)}")
print(f"✅ Sections Covered: {best_schedule['Section'].nunique()}")

# Save final result
best_schedule.to_csv("final_master_timetable.csv", index=False)

# Validate missing courses
missing_courses = set(sessions_df['Course_Key']) - set(best_schedule['Course_Key'])
print(f"\n❗ Missing Classes: {missing_courses}")
print(f"❗ Total Missing: {len(missing_courses)}")

# Why each missing class failed
missing = set(sessions_df['Course_Key']) - set(best_schedule['Course_Key'])
for key in missing:
    print("🔍 Not Scheduled:", key)
    print(sessions_df[sessions_df['Course_Key'] == key])