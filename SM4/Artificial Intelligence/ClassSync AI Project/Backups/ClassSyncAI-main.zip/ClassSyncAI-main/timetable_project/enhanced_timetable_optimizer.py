import pandas as pd
import random
from tqdm import tqdm
from datetime import time, datetime, timedelta
from collections import Counter
import numpy as np

VERBOSE = False

# ==============================
# Enhanced Configuration Settings
# ==============================
CONFIG = {
    "working_days": ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    "daily_start": time(8, 0),
    "daily_end": time(18, 30),
    "slot_duration_minutes": 90,
    "vc_slot_days": ['Monday', 'Tuesday'],
    "vc_slot_time": (time(12, 30), time(14, 0)),
    "lab_duration_slots": 2,
    "disallow_weekends": True,
    "max_daily_hours_per_instructor": 8,  # New constraint
    "preferred_gap_minutes": 30,  # Preferred gap between sessions
    "evening_penalty_threshold": time(16, 0)  # Penalty for late sessions
}

# ==============================
# Function: Load and clean data
# ==============================
def load_course_and_room_data(course_path, room_path):
    courses_df = pd.read_csv(course_path)
    rooms_df = pd.read_csv(room_path)

    courses_df.columns = courses_df.columns.str.strip()
    rooms_df.columns = rooms_df.columns.str.strip()

    courses_df['Course_Key'] = (
        courses_df['Course Name'].str.strip() + " - " +
        courses_df['Program'].str.strip() + courses_df['Section'].str.strip()
    )
    courses_df['Is_Lab'] = courses_df['Course Name'].str.contains('Lab', case=False)

    return courses_df, rooms_df

# ==============================
# Enhanced Function: Generate time slots with better handling
# ==============================
def generate_time_slots(config):
    slots = []
    start_dt = datetime.combine(datetime.today(), config["daily_start"])
    end_dt = datetime.combine(datetime.today(), config["daily_end"])
    delta = timedelta(minutes=config["slot_duration_minutes"])

    while start_dt + delta <= end_dt:
        slot_start = start_dt.time()
        slot_end = (start_dt + delta).time()
        slots.append((slot_start, slot_end))
        start_dt += delta

    filtered_slots = []
    vc_start, vc_end = config["vc_slot_time"]
    
    for day in config["working_days"]:
        for start, end in slots:
            # Skip VC slots on specified days
            if day in config["vc_slot_days"] and vc_start <= start < vc_end:
                continue
            filtered_slots.append((day, start, end))

    return filtered_slots

# ==============================
# Function: Create session entries (unchanged)
# ==============================
def create_sessions_from_courses(courses_df):
    sessions = []
    for _, row in courses_df.iterrows():
        session_count = 1 if row['Is_Lab'] else 2
        for session_num in range(session_count):
            sessions.append({
                "Course_Key": row['Course_Key'],
                "Course_Name": row['Course Name'],
                "Instructor": row['Instructor'],
                "Section": row['Section'],
                "Program": row['Program'],
                "Is_Lab": row['Is_Lab'],
                "Duration_Slots": 2 if row['Is_Lab'] else 1,
                "Session_Number": session_num + 1
            })
    return pd.DataFrame(sessions)

# ==============================
# Enhanced Function: Generate individual with better conflict resolution
# ==============================
def generate_individual(sessions_df, available_slots, rooms_df, max_trials=1000, show_progress=False):
    schedule = []
    forced_log = []
    missed_sessions = []
    
    lab_rooms = rooms_df[rooms_df['Type'].str.lower() == 'lab']['Rooms'].tolist()
    theory_rooms = rooms_df[rooms_df['Type'].str.lower() == 'theory']['Rooms'].tolist()
    all_rooms = rooms_df['Rooms'].tolist()
    
    # Enhanced prioritization
    def get_priority_score(session):
        score = 0
        if 'CS2' in session['Section'] or 'CS4' in session['Section']:
            score += 100
        if session['Is_Lab']:
            score += 50  # Labs are harder to place
        return score
    
    sessions_df['Priority_Score'] = sessions_df.apply(get_priority_score, axis=1)
    sessions_df = sessions_df.sort_values(by='Priority_Score', ascending=False)
    
    # Track instructor daily hours
    instructor_daily_hours = {}
    
    def get_instructor_hours(instructor, day):
        return instructor_daily_hours.get(f"{instructor}_{day}", 0)
    
    def add_instructor_hours(instructor, day, hours):
        key = f"{instructor}_{day}"
        instructor_daily_hours[key] = instructor_daily_hours.get(key, 0) + hours
    
    def check_conflicts(session, day, start_time, end_time, room):
        """Enhanced conflict checking"""
        for scheduled in schedule:
            if scheduled["Weekday"] != day:
                continue
                
            scheduled_start = datetime.strptime(scheduled["Start_Time"], "%H:%M").time()
            scheduled_end = datetime.strptime(scheduled["End_Time"], "%H:%M").time()
            
            # Check time overlap
            if not (end_time <= scheduled_start or start_time >= scheduled_end):
                # Room conflict
                if scheduled["Room"] == room:
                    return "room_conflict"
                # Instructor conflict
                if scheduled["Instructor"] == session["Instructor"]:
                    return "instructor_conflict"
                # Section conflict (students can't be in two places)
                if scheduled["Section"] == session["Section"]:
                    return "section_conflict"
        return None
    
    iterator = tqdm(sessions_df.iterrows(), total=len(sessions_df), 
                   desc="📅 Placing Sessions", unit="session") if show_progress else sessions_df.iterrows()
    
    for _, session in iterator:
        placed = False
        trials = 0
        best_attempt = None
        
        # Try preferred placement first
        while not placed and trials < max_trials:
            trials += 1
            day, start_time, slot_end = random.choice(available_slots)
            
            # Check instructor daily hour limits
            session_hours = 3 if session["Is_Lab"] else 1.5
            if get_instructor_hours(session["Instructor"], day) + session_hours > CONFIG["max_daily_hours_per_instructor"]:
                continue
            
            is_lab = session["Is_Lab"]
            preferred_rooms = lab_rooms if is_lab else theory_rooms
            room = random.choice(preferred_rooms)
            
            if is_lab:
                # Find consecutive slots for lab
                slot_idx = next((i for i, s in enumerate(available_slots) 
                               if s[0] == day and s[1] == start_time), -1)
                if slot_idx == -1 or slot_idx + 1 >= len(available_slots):
                    continue
                next_slot = available_slots[slot_idx + 1]
                if next_slot[0] != day:
                    continue
                end_time = next_slot[2]
                if end_time > CONFIG["daily_end"]:
                    continue
            else:
                end_time = (datetime.combine(datetime.today(), start_time) + 
                          timedelta(minutes=90)).time()
                if end_time > CONFIG["daily_end"]:
                    continue
            
            conflict = check_conflicts(session, day, start_time, end_time, room)
            if conflict is None:
                # Successfully placed
                schedule.append({
                    **session,
                    "Weekday": day,
                    "Start_Time": start_time.strftime('%H:%M'),
                    "End_Time": end_time.strftime('%H:%M'),
                    "Room": room
                })
                add_instructor_hours(session["Instructor"], day, session_hours)
                placed = True
                continue
            
            # Store best attempt for fallback
            if best_attempt is None or conflict == "section_conflict":
                best_attempt = {
                    "day": day, "start": start_time, "end": end_time, 
                    "room": room, "conflict": conflict
                }
        
        # Fallback strategies
        if not placed:
            fallback_attempts = [
                ("lab_single_slot", lab_rooms if session["Is_Lab"] else theory_rooms),
                ("any_room_instructor_only", all_rooms),
                ("any_room_relaxed", all_rooms)
            ]
            
            for strategy, room_pool in fallback_attempts:
                if placed: break
                
                for _ in range(200):
                    day, start_time, _ = random.choice(available_slots)
                    room = random.choice(room_pool)
                    
                    if strategy == "lab_single_slot" and session["Is_Lab"]:
                        # Force lab into single slot
                        end_time = (datetime.combine(datetime.today(), start_time) + 
                                  timedelta(minutes=90)).time()
                    else:
                        end_time = (datetime.combine(datetime.today(), start_time) + 
                                  timedelta(minutes=90)).time()
                    
                    if end_time > CONFIG["daily_end"]:
                        continue
                    
                    # Apply strategy-specific conflict checking
                    conflict_found = False
                    for scheduled in schedule:
                        if scheduled["Weekday"] != day:
                            continue
                        
                        scheduled_start = datetime.strptime(scheduled["Start_Time"], "%H:%M").time()
                        scheduled_end = datetime.strptime(scheduled["End_Time"], "%H:%M").time()
                        
                        if not (end_time <= scheduled_start or start_time >= scheduled_end):
                            if strategy == "any_room_relaxed":
                                # Only check instructor conflicts
                                if scheduled["Instructor"] == session["Instructor"]:
                                    conflict_found = True
                                    break
                            else:
                                # Check all conflicts except section for "any_room_instructor_only"
                                if (scheduled["Room"] == room or 
                                    scheduled["Instructor"] == session["Instructor"]):
                                    conflict_found = True
                                    break
                    
                    if not conflict_found:
                        schedule.append({
                            **session,
                            "Weekday": day,
                            "Start_Time": start_time.strftime('%H:%M'),
                            "End_Time": end_time.strftime('%H:%M'),
                            "Room": room,
                            "Forced": True,
                            "Strategy": strategy
                        })
                        
                        forced_log.append({
                            "Course": session['Course_Key'],
                            "Day": day,
                            "Start": start_time.strftime('%H:%M'),
                            "Room": room,
                            "Strategy": strategy,
                            "Relaxed": strategy == "any_room_relaxed"
                        })
                        placed = True
                        break
        
        if not placed:
            missed_sessions.append({
                "Course": session["Course_Key"],
                "Instructor": session["Instructor"],
                "Section": session["Section"],
                "Is_Lab": session["Is_Lab"],
                "Reason": f"Failed after {max_trials} trials with all fallback strategies"
            })
    
    return pd.DataFrame(schedule), forced_log, missed_sessions

# ==============================
# Function: Generate population (unchanged)
# ==============================
def generate_population(pop_size, sessions_df, available_slots, rooms_df, show_progress=False):
    population = []
    all_forced = []
    all_missed = []

    for i in range(pop_size):
        if show_progress:
            print(f"Generating individual {i+1}/{pop_size}")
        schedule, forced_log, missed_sessions = generate_individual(
            sessions_df, available_slots, rooms_df, show_progress=False
        )
        population.append(schedule)
        all_forced.extend(forced_log)
        all_missed.extend(missed_sessions)

    return population, all_forced, all_missed

# ==============================
# Enhanced Function: Calculate fitness with better scoring
# ==============================
def calculate_fitness(individual):
    if individual.empty:
        return 1
    
    penalty = 0
    bonus = 0
    
    # Convert time strings to time objects for comparison
    individual = individual.copy()
    individual['Start_Time_obj'] = pd.to_datetime(individual['Start_Time'], format="%H:%M").dt.time
    individual['End_Time_obj'] = pd.to_datetime(individual['End_Time'], format="%H:%M").dt.time
    
    # Check conflicts and calculate penalties
    for i, row in individual.iterrows():
        overlapping = individual[
            (individual['Weekday'] == row['Weekday']) &
            (individual.index != i) &
            (individual['Start_Time_obj'] < row['End_Time_obj']) &
            (individual['End_Time_obj'] > row['Start_Time_obj'])
        ]
        
        # Conflict penalties
        instructor_conflicts = overlapping[overlapping['Instructor'] == row['Instructor']]
        room_conflicts = overlapping[overlapping['Room'] == row['Room']]
        section_conflicts = overlapping[overlapping['Section'] == row['Section']]
        
        penalty += len(instructor_conflicts) * 50  # Instructor conflicts are critical
        penalty += len(room_conflicts) * 30       # Room conflicts are serious
        penalty += len(section_conflicts) * 40    # Student conflicts are serious
        
        # Penalties for forced placements
        if 'Forced' in individual.columns and pd.notna(row.get('Forced')) and row['Forced']:
            strategy = row.get('Strategy', 'unknown')
            if strategy == "lab_single_slot":
                penalty += 15  # Lab in single slot is suboptimal
            elif strategy == "any_room_instructor_only":
                penalty += 10  # Some relaxation
            elif strategy == "any_room_relaxed":
                penalty += 5   # More relaxation, less penalty
        
        # Evening time penalty (after 4 PM)
        if row['Start_Time_obj'] >= CONFIG["evening_penalty_threshold"]:
            penalty += 3
        
        # Bonus for good lab placement (2 consecutive slots)
        if row.get('Is_Lab') and not row.get('Forced', False):
            bonus += 5
    
    # Instructor daily hour distribution bonus
    instructor_hours = {}
    for _, row in individual.iterrows():
        key = f"{row['Instructor']}_{row['Weekday']}"
        duration = 3 if row.get('Is_Lab') else 1.5
        instructor_hours[key] = instructor_hours.get(key, 0) + duration
    
    # Bonus for balanced instructor schedules
    for hours in instructor_hours.values():
        if 3 <= hours <= 6:  # Good daily hour range
            bonus += 2
        elif hours > 8:      # Overloaded day
            penalty += 10
    
    # Coverage bonus (more sessions scheduled = better)
    coverage_bonus = len(individual) * 2
    
    base_score = 1000
    final_score = max(1, base_score - penalty + bonus + coverage_bonus)
    
    return final_score

# ==============================
# Enhanced Function: Better crossover
# ==============================
def crossover(parent1, parent2):
    if parent1.empty or parent2.empty:
        return parent1.copy(), parent2.copy()
    
    # Use instructor-based crossover for better preservation of good schedules
    instructors1 = set(parent1['Instructor'].unique())
    instructors2 = set(parent2['Instructor'].unique())
    common_instructors = instructors1.intersection(instructors2)
    
    if common_instructors:
        # Split by instructor rather than random position
        split_instructor = random.choice(list(common_instructors))
        
        child1_part1 = parent1[parent1['Instructor'] <= split_instructor]
        child1_part2 = parent2[parent2['Instructor'] > split_instructor]
        
        child2_part1 = parent2[parent2['Instructor'] <= split_instructor]
        child2_part2 = parent1[parent1['Instructor'] > split_instructor]
        
        child1 = pd.concat([child1_part1, child1_part2], ignore_index=True)
        child2 = pd.concat([child2_part1, child2_part2], ignore_index=True)
    else:
        # Fallback to positional crossover
        split = len(parent1) // 2
        child1 = pd.concat([parent1.iloc[:split], parent2.iloc[split:]], ignore_index=True)
        child2 = pd.concat([parent2.iloc[:split], parent1.iloc[split:]], ignore_index=True)
    
    # Remove duplicates while preserving course session requirements
    child1 = child1.drop_duplicates(subset=["Course_Key", "Session_Number"], keep='first')
    child2 = child2.drop_duplicates(subset=["Course_Key", "Session_Number"], keep='first')
    
    return child1.reset_index(drop=True), child2.reset_index(drop=True)

# ==============================
# Enhanced Function: Better mutation
# ==============================
def mutate(individual, available_slots, rooms_df, mutation_rate=0.1):
    if individual.empty or random.random() >= mutation_rate:
        return individual
    
    individual = individual.copy()
    lab_rooms = rooms_df[rooms_df['Type'].str.lower() == 'lab']['Rooms'].tolist()
    theory_rooms = rooms_df[rooms_df['Type'].str.lower() == 'theory']['Rooms'].tolist()
    
    # Choose multiple sessions to mutate for better exploration
    num_mutations = max(1, int(len(individual) * mutation_rate))
    mutation_indices = random.sample(range(len(individual)), 
                                   min(num_mutations, len(individual)))
    
    for idx in mutation_indices:
        session = individual.iloc[idx]
        is_lab = session.get('Is_Lab', False)
        preferred_rooms = lab_rooms if is_lab else theory_rooms
        
        for _ in range(50):  # Try to find better placement
            day, start_time, _ = random.choice(available_slots)
            room = random.choice(preferred_rooms)
            
            if is_lab:
                # Try to get consecutive slots
                slot_idx = next((i for i, s in enumerate(available_slots) 
                               if s[0] == day and s[1] == start_time), -1)
                if slot_idx != -1 and slot_idx + 1 < len(available_slots):
                    next_slot = available_slots[slot_idx + 1]
                    if next_slot[0] == day:
                        end_time = next_slot[2]
                    else:
                        end_time = (datetime.combine(datetime.today(), start_time) + 
                                  timedelta(minutes=90)).time()
                else:
                    end_time = (datetime.combine(datetime.today(), start_time) + 
                              timedelta(minutes=90)).time()
            else:
                end_time = (datetime.combine(datetime.today(), start_time) + 
                          timedelta(minutes=90)).time()
            
            if end_time <= CONFIG["daily_end"]:
                individual.at[idx, 'Weekday'] = day
                individual.at[idx, 'Start_Time'] = start_time.strftime('%H:%M')
                individual.at[idx, 'End_Time'] = end_time.strftime('%H:%M')
                individual.at[idx, 'Room'] = room
                
                # Remove forced flags if mutation improves placement
                if 'Forced' in individual.columns:
                    individual.at[idx, 'Forced'] = False
                if 'Strategy' in individual.columns:
                    individual.at[idx, 'Strategy'] = None
                break
    
    return individual

# ==============================
# Enhanced Function: Optimize with adaptive parameters
# ==============================
def optimize(population, available_slots, rooms_df, generations=100, elite_size=3, 
            mutation_rate=0.15, adaptive=True):
    best_fitness_history = []
    stagnation_counter = 0
    current_mutation_rate = mutation_rate
    
    room_list = rooms_df['Rooms'].tolist()
    
    progress_bar = tqdm(
        range(generations),
        desc="🧬 Optimizing Schedule",
        unit="gen"
    )
    
    for gen in progress_bar:
        # Calculate fitness for all individuals
        fitness_scores = [calculate_fitness(ind) for ind in population]
        best_fitness = max(fitness_scores)
        avg_fitness = np.mean(fitness_scores)
        best_fitness_history.append(best_fitness)
        
        # Update progress bar
        progress_bar.set_postfix({
            'Best': f'{best_fitness:.0f}',
            'Avg': f'{avg_fitness:.0f}',
            'MutRate': f'{current_mutation_rate:.3f}'
        })
        
        # Adaptive mutation rate
        if adaptive and gen > 0:
            if best_fitness <= best_fitness_history[-2]:
                stagnation_counter += 1
                if stagnation_counter > 10:
                    current_mutation_rate = min(0.3, current_mutation_rate * 1.1)
                    stagnation_counter = 0
            else:
                stagnation_counter = 0
                current_mutation_rate = max(0.05, current_mutation_rate * 0.95)
        
        # Selection: Elite + Tournament
        elite_indices = sorted(range(len(fitness_scores)), 
                             key=lambda i: fitness_scores[i], reverse=True)[:elite_size]
        new_population = [population[i].copy() for i in elite_indices]
        
        # Fill rest with crossover and mutation
        while len(new_population) < len(population):
            # Tournament selection
            tournament_size = 3
            parent1_idx = max(random.sample(range(len(population)), tournament_size),
                            key=lambda i: fitness_scores[i])
            parent2_idx = max(random.sample(range(len(population)), tournament_size),
                            key=lambda i: fitness_scores[i])
            
            parent1 = population[parent1_idx]
            parent2 = population[parent2_idx]
            
            child1, child2 = crossover(parent1, parent2)
            
            new_population.append(mutate(child1, available_slots, rooms_df, current_mutation_rate))
            if len(new_population) < len(population):
                new_population.append(mutate(child2, available_slots, rooms_df, current_mutation_rate))
        
        population = new_population
    
    # Return best individual
    final_scores = [calculate_fitness(ind) for ind in population]
    best_index = final_scores.index(max(final_scores))
    
    return population[best_index], final_scores[best_index], best_fitness_history

# ==============================
# Enhanced reporting functions
# ==============================
def format_schedule_by_day(schedule_df):
    """Enhanced schedule formatting with conflict highlighting"""
    if schedule_df.empty:
        print("❌ No schedule to display - empty DataFrame")
        return
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    
    for day in days:
        day_df = schedule_df[schedule_df['Weekday'] == day]
        if day_df.empty:
            continue
            
        print(f"\n📅 {day.upper()}")
        print("=" * 80)
        
        # Sort by start time
        day_df = day_df.sort_values(by='Start_Time')
        
        for _, row in day_df.iterrows():
            forced_marker = ""
            if row.get('Forced', False):
                strategy = row.get('Strategy', 'unknown')
                if row.get('Relaxed', False):
                    forced_marker = " [RELAXED]"
                else:
                    forced_marker = f" [FORCED:{strategy}]"
            
            lab_marker = " [LAB]" if row.get('Is_Lab', False) else ""
            
            print(f"{row['Start_Time']}-{row['End_Time']} | "
                  f"{row['Course_Key']:<35} | "
                  f"{row['Instructor']:<20} | "
                  f"{row['Room']:<10}"
                  f"{lab_marker}{forced_marker}")

def analyze_schedule_quality(schedule_df, sessions_df):
    """Comprehensive schedule analysis"""
    print("\n📊 SCHEDULE QUALITY ANALYSIS")
    print("=" * 50)
    
    total_expected = len(sessions_df)
    total_scheduled = len(schedule_df)
    coverage = (total_scheduled / total_expected * 100) if total_expected > 0 else 0
    
    print(f"📈 Coverage: {total_scheduled}/{total_expected} sessions ({coverage:.1f}%)")
    
    if not schedule_df.empty:
        # Forced placements analysis
        forced_count = len(schedule_df[schedule_df.get('Forced', False) == True])
        if forced_count > 0:
            print(f"⚠️  Forced placements: {forced_count}")
            
            strategies = schedule_df[schedule_df.get('Forced', False) == True]['Strategy'].value_counts()
            for strategy, count in strategies.items():
                print(f"   - {strategy}: {count}")
        
        # Instructor workload
        instructor_sessions = schedule_df['Instructor'].value_counts()
        print(f"\n👥 Instructor workload (top 5):")
        for instructor, count in instructor_sessions.head().items():
            print(f"   - {instructor}: {count} sessions")
        
        # Room utilization
        room_usage = schedule_df['Room'].value_counts()
        print(f"\n🏢 Room utilization (top 5):")
        for room, count in room_usage.head().items():
            print(f"   - {room}: {count} sessions")
        
        # Time distribution
        print(f"\n⏰ Time slot distribution:")
        time_dist = schedule_df['Start_Time'].value_counts().sort_index()
        for time_slot, count in time_dist.items():
            print(f"   - {time_slot}: {count} sessions")

def check_long_sessions(df):
    """Check for sessions exceeding 3 hours"""
    long_sessions = []
    for _, row in df.iterrows():
        start = datetime.strptime(row["Start_Time"], "%H:%M")
        end = datetime.strptime(row["End_Time"], "%H:%M")
        duration = (end - start).seconds / 60
        if duration > 180:
            long_sessions.append((row["Course_Key"], row["Weekday"], 
                                row["Start_Time"], row["End_Time"], duration))
    return long_sessions

def export_schedule_by_section(schedule_df, output_dir="exports"):
    """Export schedules grouped by section"""
    import os
    
    if schedule_df.empty:
        print("No schedule data to export")
        return
    
    os.makedirs(output_dir, exist_ok=True)
    
    sections = schedule_df['Section'].unique()
    
    for section in sections:
        section_df = schedule_df[schedule_df['Section'] == section]
        filename = f"{output_dir}/schedule_{section}.csv"
        section_df.to_csv(filename, index=False)
        print(f"📄 Exported {section} schedule to {filename}")
    
    # Also export master schedule
    master_filename = f"{output_dir}/master_schedule.csv"
    schedule_df.to_csv(master_filename, index=False)
    print(f"📄 Exported master schedule to {master_filename}")