package com.springproduct.controller;

import com.springproduct.model.Product;
import com.springproduct.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/product")
@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public Product productById(@PathVariable Long id) {
        return productService.getProduct(id);
    }

    @GetMapping("/{name}")
    public Product productByName(@PathVariable String name) {
        return productService.getProduct(name);
    }

    @PostMapping
    public void addProduct(@RequestBody Product product) {
        productService.addProduct(product);
    }

    @PutMapping
    public void updateProduct(@RequestBody Product product) {
        productService.updateProduct(product);
    }
    @DeleteMapping
    public void deleteProduct(@RequestBody Product product) {
        productService.deleteProduct(product.getId().longValue());
    }

}
