package com.springproduct.service;

import com.springproduct.model.Product;
import com.springproduct.model.ProductDetail;
import com.springproduct.repository.ProductDetailRepository;
import com.springproduct.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductDetailService {

    @Autowired
    private ProductDetailRepository productDetailRepository;

    public List<ProductDetail> getAllProductDetails() {
        return productDetailRepository.findAll();
    }

    public ProductDetail getProductDetail(Long id) {
        return productDetailRepository.findById(id).get();
    }

    public ProductDetail getProductDetail(String description) {
        return productDetailRepository.getProductDetailByProductDescription(description);
    }

    public void addProductDetail(ProductDetail productDetail) {
        productDetailRepository.save(productDetail);
    }
    public void updateProduct(ProductDetail productDetail) {
        productDetailRepository.save(productDetail);
    }

    public void deleteProductDetail(Long id) {
        productDetailRepository.deleteById(id);
    }
}
