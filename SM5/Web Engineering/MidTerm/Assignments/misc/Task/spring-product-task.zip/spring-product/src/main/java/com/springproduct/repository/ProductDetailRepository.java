package com.springproduct.repository;

import com.springproduct.model.ProductDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductDetailRepository extends JpaRepository<ProductDetail, Long> {
    public ProductDetail getProductDetailByProductDescription(String description);
}
