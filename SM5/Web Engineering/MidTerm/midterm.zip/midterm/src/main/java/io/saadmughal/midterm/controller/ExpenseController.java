package io.saadmughal.midterm.controller;

import io.saadmughal.midterm.service.ExpenseService;
import io.saadmughal.midterm.entities.Expense;
import io.saadmughal.midterm.entities.Member;
import io.saadmughal.midterm.entities.Category;
import io.saadmughal.midterm.repositories.MemberRepository;
import io.saadmughal.midterm.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/expenses")
@CrossOrigin
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    // Get all expenses
    @GetMapping
    public List<Expense> getAllExpenses() {
        return expenseService.getAllExpenses();
    }

    // Get expenses by member
    @GetMapping("/member/{id}")
    public List<Expense> getExpensesByMember(@PathVariable Integer id) {
        return expenseService.getExpensesByMember(id);
    }

    // Get expenses by category
    @GetMapping("/category/{id}")
    public List<Expense> getExpensesByCategory(@PathVariable Integer id) {
        return expenseService.getExpensesByCategory(id);
    }

    // Add expense
    @PostMapping
    public Expense addExpense(@RequestBody Map<String, Object> payload) {

        Expense expense = new Expense();
        expense.setDate((String) payload.get("date"));
        expense.setAmount(new java.math.BigDecimal(payload.get("amount").toString()));
        expense.setDescription((String) payload.get("description"));

        Integer memberId = (Integer) payload.get("memberId");
        Integer categoryId = (Integer) payload.get("categoryId");

        Member member = memberRepository.findById(memberId).orElseThrow();
        Category category = categoryRepository.findById(categoryId).orElseThrow();

        // Match field names in Expense.java
        expense.setMembers(member);
        expense.setCategories(category);

        return expenseService.addExpense(expense);
    }

    // Update expense
    @PutMapping("/{id}")
    public Expense updateExpense(@PathVariable Integer id, @RequestBody Map<String, Object> payload) {

        Expense expenseDetails = new Expense();
        expenseDetails.setDate((String) payload.get("date"));
        expenseDetails.setAmount(new java.math.BigDecimal(payload.get("amount").toString()));
        expenseDetails.setDescription((String) payload.get("description"));

        Integer memberId = (Integer) payload.get("memberId");
        Integer categoryId = (Integer) payload.get("categoryId");

        Member member = memberRepository.findById(memberId).orElseThrow();
        Category category = categoryRepository.findById(categoryId).orElseThrow();

        expenseDetails.setMembers(member);
        expenseDetails.setCategories(category);

        return expenseService.updateExpense(id, expenseDetails);
    }

    // Delete expense
    @DeleteMapping("/{id}")
    public void deleteExpense(@PathVariable Integer id) {
        expenseService.deleteExpense(id);
    }
}