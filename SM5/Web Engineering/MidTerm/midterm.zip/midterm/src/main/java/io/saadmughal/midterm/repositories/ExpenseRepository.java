package io.saadmughal.midterm.repositories;

import io.saadmughal.midterm.entities.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Integer> {
    List<Expense> findByMembers_Id(Integer id);
    List<Expense> findByCategories_Id(Integer id);
}