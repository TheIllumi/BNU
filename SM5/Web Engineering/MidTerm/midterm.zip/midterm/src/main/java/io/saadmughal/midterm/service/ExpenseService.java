package io.saadmughal.midterm.service;

import io.saadmughal.midterm.entities.Expense;
import io.saadmughal.midterm.repositories.ExpenseRepository;
import io.saadmughal.midterm.repositories.MemberRepository;
import io.saadmughal.midterm.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    // Get all expenses
    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll();
    }

    // Add expense
    public Expense addExpense(Expense expense) {
        return expenseRepository.save(expense);
    }

    // Get expenses by category
    public List<Expense> getExpensesByCategory(int categoryId) {
        return expenseRepository.findByCategories_Id(categoryId);
    }

    // Get expenses by member
    public List<Expense> getExpensesByMember(int memberId) {
        return expenseRepository.findByMembers_Id(memberId);
    }

    // Update expense
    public Expense updateExpense(Integer id, Expense expenseDetails) {
        Expense expense = expenseRepository.findById(id).orElseThrow();
        expense.setDate(expenseDetails.getDate());
        expense.setAmount(expenseDetails.getAmount());
        expense.setDescription(expenseDetails.getDescription());
        expense.setMembers(expenseDetails.getMembers());
        expense.setCategories(expenseDetails.getCategories());
        return expenseRepository.save(expense);
    }

    // Delete expense
    public void deleteExpense(Integer id) {
        expenseRepository.deleteById(id);
    }
}