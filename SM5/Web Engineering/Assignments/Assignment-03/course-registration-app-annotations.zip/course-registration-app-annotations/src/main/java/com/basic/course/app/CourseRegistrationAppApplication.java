package com.basic.course.app;

import com.basic.course.app.bean.Course;
import com.basic.course.app.bean.Registration;
import com.basic.course.app.bean.Student;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.time.LocalDate;

@SpringBootApplication(scanBasePackages = "com.basic.course.app")
public class CourseRegistrationAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseRegistrationAppApplication.class, args);
        init();
    }

    public static void init(){
        //course definition
        Course pf104 = new Course("Programming Fundamentals","Programming Fundamentals","CSC-104");
        pf104.setPrerequisiteCourse(null);
        Course oop205 = new Course("Object Oriented Programming","Object Oriented Programming","CSC-205");
        oop205.setPrerequisiteCourse(pf104);
        Course ds311 = new Course("Data Structures & Algorithms","Data Structures & Algorithms","CSC-311");
        ds311.setPrerequisiteCourse(oop205);


        Student st100 = new Student("f2024-543","Muhammad Ahmad","Lahore");
        Student st101 = new Student("f2024-599","Arshad Khan","Lahore");


        Registration registration100 = new Registration(st100,oop205,"Fall 2025",LocalDate.now());
        Registration registration101 = new Registration(st101,ds311,"Fall 2025",LocalDate.now());
        //oop205.addRegistration(registration100);
        //st100.addRegistration(registration100);

        //st101.addRegistration(registration101);
       // ds311.addRegistration(registration101);

        System.out.println(registration100);
        System.out.println(registration101);

    }

}
