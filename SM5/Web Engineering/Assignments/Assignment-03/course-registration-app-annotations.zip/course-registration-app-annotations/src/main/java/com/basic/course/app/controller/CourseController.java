package com.basic.course.app.controller;

import com.basic.course.app.bean.Course;
import com.basic.course.app.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping
    public String addCourse(@RequestBody Course course) {
        courseService.addCourse(course);
        return "Course added successfully!";
    }
    @PostMapping("/bulk")
    public String addCourseBulk(@RequestBody List<Course> course) {
        for (Course c : course) {
            courseService.addCourse(c);
        }
        return "Course added successfully!";
    }

    @GetMapping
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/{id}")
    public Course getCourseById(@PathVariable Long id) {
        return courseService.getCourseById(id);
    }

    @PutMapping("/{id}")
    public String updateCourse(@PathVariable Long id, @RequestBody Course updatedCourse) {
        updatedCourse.setCourseId(id);
        courseService.updateCourse(updatedCourse);
        return "Course updated successfully!";
    }

    @DeleteMapping("/{id}")
    public String deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return "Course deleted successfully!";
    }
}
