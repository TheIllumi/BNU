package com.basic.course.app.controller;

import com.basic.course.app.bean.Course;
import com.basic.course.app.bean.Student;
import com.basic.course.app.dao.impl.CourseDAOImpl;
import com.basic.course.app.dao.impl.StudentDAOImpl;
import com.basic.course.app.service.CourseService;
import com.basic.course.app.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping
    public String addStudent(@RequestBody Student student) {
        studentService.addStudent(student);
        return "Student added successfully!";
    }
    @PostMapping("/bulk")
    public String addStudent(@RequestBody List<Student> student) {
        for (Student s: student) {
            studentService.addStudent(s);
        }
        return "Student added successfully!";
    }

    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable Long id) {
        return studentService.getStudentById(id);
    }

    @PutMapping("/{id}")
    public String updateStudent(@PathVariable Integer id, @RequestBody Student updatedStudent) {
        updatedStudent.setStudentId(id);
        studentService.updateStudent(updatedStudent);
        return "Student updated successfully!";
    }

    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return "Student deleted successfully!";
    }
}
