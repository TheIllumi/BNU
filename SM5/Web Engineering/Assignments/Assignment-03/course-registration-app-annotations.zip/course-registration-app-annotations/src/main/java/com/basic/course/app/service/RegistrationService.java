package com.basic.course.app.service;

import com.basic.course.app.bean.Registration;
import com.basic.course.app.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class RegistrationService {
    @Autowired
    private RegistrationRepository registrationRepository;

    public RegistrationService() {

    }

    @Transactional
    public void addRegistration(Registration registration) {
        registrationRepository.save(registration);
    }

    public List<Registration> getAllRegistrations() {
        return registrationRepository.findAll();
    }

    public Registration getRegistrationById(Long id) {
        return registrationRepository.findById(id).get();
    }

    @Transactional
    public void updateRegistration(Registration registration) {
        registrationRepository.save(registration);
    }

    @Transactional
    public void deleteRegistration(Long id) {
        registrationRepository.delete(registrationRepository.findById(id).get());
    }
}
