package com.basic.course.app.controller;

import com.basic.course.app.bean.Registration;
import com.basic.course.app.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/registrations")
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService ;

    @PostMapping
    public String addRegistration(@RequestBody Registration registration) {
        registrationService.addRegistration(registration);
        return "Registration added successfully!";
    }
    @PostMapping("/bulk")
    public String addRegistration(@RequestBody List<Registration> registration) {
        for (Registration r : registration) {
            registrationService.addRegistration(r);
        }
        return "Registration added successfully!";
    }

    @GetMapping
    public List<Registration> getAllRegistration() {
        return registrationService.getAllRegistrations();
    }

    @GetMapping("/{id}")
    public Registration getRegistrationById(@PathVariable Long id) {
        return registrationService.getRegistrationById(id);
    }

    @PutMapping("/{id}")
    public String updateRegistration(@PathVariable Integer id, @RequestBody Registration updatedRegistration) {
        updatedRegistration.setRegistrationId(id);
        registrationService.updateRegistration(updatedRegistration);
        return "Registration updated successfully!";
    }

    @DeleteMapping("/{id}")
    public String deleteRegistration(@PathVariable Long id) {
        registrationService.deleteRegistration(id);
        return "Registration deleted successfully!";
    }
}
