import { useState, useEffect, useCallback } from "react";
import { formatEther, formatUnits } from "ethers";

export function useChainStats(provider, account) {
  const [stats, setStats] = useState({
    blockNumber: null,
    gasPrice: null,     // in Gwei
    ethBalance: null,   // in ETH
    lastTxHash: null,
    lastGasUsed: null,
    lastGasCost: null,  // in ETH
  });

  const fetchStats = useCallback(async () => {
    if (!provider || !account) return;
    try {
      const [block, feeData, balance] = await Promise.all([
        provider.getBlockNumber(),
        provider.getFeeData(),
        provider.getBalance(account),
      ]);
      setStats(prev => ({
        ...prev,
        blockNumber: block,
        gasPrice: feeData.gasPrice
          ? parseFloat(formatUnits(feeData.gasPrice, "gwei")).toFixed(2)
          : null,
        ethBalance: parseFloat(formatEther(balance)).toFixed(4),
      }));
    } catch (e) {
      console.error("fetchStats:", e);
    }
  }, [provider, account]);

  // Poll every 12 s (approx one Ethereum block)
  useEffect(() => {
    if (!provider || !account) return;
    fetchStats();
    const id = setInterval(fetchStats, 12000);
    return () => clearInterval(id);
  }, [provider, account, fetchStats]);

  const recordTx = useCallback(async (receipt) => {
    if (!receipt) return;
    try {
      const feeData = await provider.getFeeData();
      const gasUsed = receipt.gasUsed;
      const gasPrice = receipt.gasPrice ?? feeData.gasPrice ?? 0n;
      const gasCost = gasUsed * gasPrice;
      setStats(prev => ({
        ...prev,
        lastTxHash: receipt.hash,
        lastGasUsed: gasUsed.toString(),
        lastGasCost: parseFloat(formatEther(gasCost)).toFixed(8),
      }));
    } catch (e) {
      console.error("recordTx:", e);
    }
  }, [provider]);

  return { stats, fetchStats, recordTx };
}
