import { useState, useEffect, useCallback } from "react";
import { useWallet } from "./hooks/useWallet.js";
import { useContract } from "./hooks/useContract.js";
import { useChainStats } from "./hooks/useChainStats.js";
import TaskCard from "./components/TaskCard.jsx";
import GasPanel from "./components/GasPanel.jsx";
import "./App.css";

// ── Dummy tasks shown before wallet connects ──────────────────
const DUMMY_TASKS = [
  { id: "3", content: "Deploy TodoContract on Sepolia testnet", isCompleted: true,  owner: "0xDEMO...0001" },
  { id: "2", content: "Connect React frontend with ethers.js v6", isCompleted: true,  owner: "0xDEMO...0001" },
  { id: "1", content: "Write thesis report by Thursday 21 May", isCompleted: false, owner: "0xDEMO...0001" },
];

const DUMMY_STATS = {
  blockNumber: 7849231,
  gasPrice: "1.42",
  ethBalance: "0.2500",
  lastTxHash: null,
  lastGasUsed: null,
  lastGasCost: null,
};

export default function App() {
  const {
    account, provider, chainOk, connecting,
    error: walletError, connect, switchToSepolia,
  } = useWallet();

  const { stats, recordTx } = useChainStats(provider, account);

  const {
    tasks, loading, txStatus, txMsg,
    loadTasks, createTask, toggleTask, editTask, deleteTask,
  } = useContract(provider, recordTx);

  const [input, setInput]       = useState("");
  const [filter, setFilter]     = useState("all");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (provider && chainOk) loadTasks();
  }, [provider, chainOk]);

  const handleCreate = async () => {
    if (!input.trim() || submitting) return;
    setSubmitting(true);
    await createTask(input.trim());
    setInput("");
    setSubmitting(false);
  };

  // Show dummy data when not connected, real data otherwise
  const isDemo   = !account || !chainOk;
  const allTasks = isDemo ? DUMMY_TASKS : tasks;
  const liveStats = isDemo ? DUMMY_STATS : stats;

  const filtered = allTasks.filter(t => {
    if (filter === "pending") return !t.isCompleted;
    if (filter === "done")    return t.isCompleted;
    return true;
  });

  const pending = allTasks.filter(t => !t.isCompleted).length;
  const done    = allTasks.filter(t => t.isCompleted).length;

  return (
    <div className="app">
      <div className="bg-grid" aria-hidden="true" />

      {/* ── Header ── */}
      <header className="header">
        <div className="logo">
          <div className="logo-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
              <rect x="14" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
              <rect x="3" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
              <rect x="14" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
            </svg>
          </div>
          <span className="logo-text">Web3 Todo</span>
          <span className="logo-badge">Sepolia</span>
        </div>

        {account ? (
          <div className="wallet-pill">
            <span className="wallet-dot" />
            <span className="wallet-addr">{account.slice(0, 6)}…{account.slice(-4)}</span>
          </div>
        ) : (
          <button className="connect-btn" onClick={connect} disabled={connecting}>
            {connecting ? "Connecting…" : "Connect Wallet"}
          </button>
        )}
      </header>

      {/* ── Body ── */}
      <div className="body-layout">

        {/* ── Left: main content ── */}
        <main className="main">

          {/* Wrong network banner */}
          {account && !chainOk && (
            <div className="network-banner">
              <span>⚠ Wrong network —</span>
              <button className="banner-btn" onClick={switchToSepolia}>Switch to Sepolia</button>
            </div>
          )}

          {/* Demo banner */}
          {isDemo && (
            <div className="demo-banner">
              <span>👻 Demo mode — connect your wallet to use the live contract</span>
              {!account && (
                <button className="banner-btn" onClick={connect} disabled={connecting}>
                  {connecting ? "Connecting…" : "Connect"}
                </button>
              )}
            </div>
          )}
          {walletError && <p className="err-msg" style={{ marginTop: 0 }}>{walletError}</p>}

          {/* Stats bar */}
          <div className="stats-bar">
            <div className="stat">
              <span className="stat-val">{allTasks.length}</span>
              <span className="stat-label">Total</span>
            </div>
            <div className="stat-divider"/>
            <div className="stat">
              <span className="stat-val pending-val">{pending}</span>
              <span className="stat-label">Pending</span>
            </div>
            <div className="stat-divider"/>
            <div className="stat">
              <span className="stat-val done-val">{done}</span>
              <span className="stat-label">Done</span>
            </div>
            <div className="stat-divider"/>
            <div className="stat">
              <span className="stat-val" style={{ fontSize: "1rem" }}>
                {allTasks.length > 0 ? Math.round((done / allTasks.length) * 100) : 0}%
              </span>
              <span className="stat-label">Complete</span>
            </div>
          </div>

          {/* Input — only when connected */}
          {!isDemo && (
            <div className="input-row">
              <input
                className="task-input"
                placeholder="Add a new task…"
                value={input}
                maxLength={280}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") handleCreate(); }}
                disabled={submitting}
              />
              <button
                className="add-btn"
                onClick={handleCreate}
                disabled={!input.trim() || submitting}
              >
                {submitting ? (
                  <span className="spinner" />
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                  </svg>
                )}
              </button>
            </div>
          )}

          {/* Filter tabs */}
          <div className="filter-tabs">
            {["all", "pending", "done"].map(f => (
              <button
                key={f}
                className={`filter-tab ${filter === f ? "active" : ""}`}
                onClick={() => setFilter(f)}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
            {!isDemo && (
              <button className="refresh-btn" onClick={loadTasks} title="Refresh from chain">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="23 4 23 10 17 10"/>
                  <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
                </svg>
              </button>
            )}
          </div>

          {/* Task list */}
          {loading ? (
            <div className="loading-state">
              <span className="spinner lg" />
              <span>Loading from chain…</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <span className="empty-icon">◎</span>
              <p>{filter === "all" ? "No tasks yet. Add one above." : `No ${filter} tasks.`}</p>
            </div>
          ) : (
            <div className="task-list">
              {filtered.map(task => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onToggle={isDemo ? () => {} : toggleTask}
                  onEdit={isDemo ? () => {} : editTask}
                  onDelete={isDemo ? () => {} : deleteTask}
                  demo={isDemo}
                />
              ))}
            </div>
          )}
        </main>

        {/* ── Right: Gas Panel ── */}
        <aside className="sidebar">
          <GasPanel stats={liveStats} account={account} />
        </aside>
      </div>

      {/* ── TX Toast ── */}
      {txStatus && (
        <div className={`toast toast-${txStatus}`}>
          {txStatus === "pending" && <span className="spinner sm" />}
          {txStatus === "success" && <span className="toast-icon">✓</span>}
          {txStatus === "error"   && <span className="toast-icon">✗</span>}
          <span>{txMsg}</span>
        </div>
      )}
    </div>
  );
}
