import { useState, useEffect, useCallback } from "react";
import { BrowserProvider } from "ethers";
import { SEPOLIA_CHAIN_ID } from "../contract.js";

export function useWallet() {
  const [account, setAccount]     = useState(null);
  const [provider, setProvider]   = useState(null);
  const [chainOk, setChainOk]     = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [error, setError]         = useState(null);

  const checkChain = useCallback(async () => {
    if (!window.ethereum) return;
    const chainId = await window.ethereum.request({ method: "eth_chainId" });
    setChainOk(chainId === SEPOLIA_CHAIN_ID);
  }, []);

  const connect = useCallback(async () => {
    if (!window.ethereum) {
      setError("MetaMask not detected. Please install it.");
      return;
    }
    try {
      setConnecting(true);
      setError(null);
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      setAccount(accounts[0]);
      const p = new BrowserProvider(window.ethereum);
      setProvider(p);
      await checkChain();
    } catch (e) {
      setError(e.message || "Connection failed");
    } finally {
      setConnecting(false);
    }
  }, [checkChain]);

  const switchToSepolia = useCallback(async () => {
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: SEPOLIA_CHAIN_ID }],
      });
      setChainOk(true);
    } catch (e) {
      setError("Could not switch network: " + e.message);
    }
  }, []);

  useEffect(() => {
    if (!window.ethereum) return;
    window.ethereum.on("accountsChanged", (accs) => setAccount(accs[0] || null));
    window.ethereum.on("chainChanged", () => checkChain());
    return () => {
      window.ethereum.removeAllListeners("accountsChanged");
      window.ethereum.removeAllListeners("chainChanged");
    };
  }, [checkChain]);

  return { account, provider, chainOk, connecting, error, connect, switchToSepolia };
}
