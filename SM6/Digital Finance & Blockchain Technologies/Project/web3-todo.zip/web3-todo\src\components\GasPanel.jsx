export default function GasPanel({ stats, account }) {
  const shortHash = (h) => h ? `${h.slice(0, 10)}…${h.slice(-6)}` : null;

  const rows = [
    {
      icon: "⛽",
      label: "Gas Price",
      value: stats.gasPrice ? `${stats.gasPrice} Gwei` : "—",
      mono: true,
    },
    {
      icon: "◼",
      label: "Block",
      value: stats.blockNumber ? `#${stats.blockNumber.toLocaleString()}` : "—",
      mono: true,
    },
    {
      icon: "◈",
      label: "ETH Balance",
      value: stats.ethBalance != null ? `${stats.ethBalance} ETH` : "—",
      mono: true,
      accent: true,
    },
    {
      icon: "↳",
      label: "Last Tx",
      value: stats.lastTxHash ? shortHash(stats.lastTxHash) : "None yet",
      mono: true,
      link: stats.lastTxHash
        ? `https://sepolia.etherscan.io/tx/${stats.lastTxHash}`
        : null,
    },
    {
      icon: "⌁",
      label: "Gas Used",
      value: stats.lastGasUsed
        ? parseInt(stats.lastGasUsed).toLocaleString() + " units"
        : "—",
      mono: true,
    },
    {
      icon: "◎",
      label: "Tx Cost",
      value: stats.lastGasCost ? `${stats.lastGasCost} ETH` : "—",
      mono: true,
    },
  ];

  return (
    <div className="gas-panel">
      <div className="gas-panel-header">
        <span className="gas-panel-title">Chain Stats</span>
        <span className="gas-live-dot" title="Live" />
      </div>
      <div className="gas-rows">
        {rows.map((r) => (
          <div className="gas-row" key={r.label}>
            <span className="gas-row-icon">{r.icon}</span>
            <span className="gas-row-label">{r.label}</span>
            {r.link ? (
              <a
                className="gas-row-value gas-link"
                href={r.link}
                target="_blank"
                rel="noreferrer"
              >
                {r.value} ↗
              </a>
            ) : (
              <span
                className={`gas-row-value ${r.mono ? "mono" : ""} ${r.accent ? "accent" : ""}`}
              >
                {r.value}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
