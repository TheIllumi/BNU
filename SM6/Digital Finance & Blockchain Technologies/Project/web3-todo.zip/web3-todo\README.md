# Web3 To-Do DApp

Decentralized task management on Ethereum Sepolia Testnet.  
**BNU — Digital Finance & Blockchain Technologies**  
Team: Saad Mughal · Khadijah Zahoor · Sara Haider · Syed Shahmeer Bakht

---

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:5173

---

## After Deploying the Contract

1. Deploy `TodoContract.sol` on Remix → Sepolia
2. Copy the **contract address**
3. Open `src/contract.js`
4. Replace `"0xYOUR_CONTRACT_ADDRESS_HERE"` with your real address
5. Save → the app auto-reloads

---

## Deploy to Vercel (free, 1 minute)

```bash
npm run build
```

Then drag the `dist/` folder to **vercel.com/new** — done.

Or via CLI:
```bash
npm i -g vercel
vercel --prod
```

---

## Deploy to GitHub Pages

1. Push this folder to a GitHub repo
2. In `vite.config.js`, set `base: '/your-repo-name/'`
3. Run `npm run build`
4. Push `dist/` contents to the `gh-pages` branch

---

## Tech Stack

| Layer | Tool |
|---|---|
| Smart Contract | Solidity 0.8.19 |
| Blockchain | Ethereum Sepolia Testnet |
| Wallet | MetaMask |
| Frontend | React 18 + Vite |
| Web3 Library | ethers.js v6 |
| Fonts | Syne + DM Mono (Google Fonts) |
| Hosting | Vercel / GitHub Pages |
