import { useState } from "react";

export default function TaskCard({ task, onToggle, onEdit, onDelete, demo }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft]     = useState(task.content);
  const [busy, setBusy]       = useState(false);

  const shortAddr = task.owner
    ? `${task.owner.slice(0, 6)}…${task.owner.slice(-4)}`
    : "";

  const handleEdit = async () => {
    if (!draft.trim() || draft === task.content) { setEditing(false); return; }
    if (demo) { setEditing(false); return; }
    setBusy(true);
    await onEdit(task.id, draft.trim());
    setBusy(false);
    setEditing(false);
  };

  return (
    <div className={`task-card ${task.isCompleted ? "done" : ""} ${demo ? "demo-card" : ""}`}>
      <div className="task-left">
        <button
          className={`check-btn ${task.isCompleted ? "checked" : ""}`}
          onClick={() => !demo && onToggle(task.id)}
          title={demo ? "Connect wallet to interact" : task.isCompleted ? "Mark pending" : "Mark done"}
          style={{ cursor: demo ? "default" : "pointer" }}
        >
          {task.isCompleted && (
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2 7l4 4 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
        </button>

        <div className="task-body">
          {editing ? (
            <input
              className="edit-input"
              value={draft}
              maxLength={280}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handleEdit(); if (e.key === "Escape") setEditing(false); }}
              autoFocus
            />
          ) : (
            <p className="task-content">{task.content}</p>
          )}
          <span className="task-meta">ID #{task.id} · {shortAddr}</span>
        </div>
      </div>

      {!demo && (
        <div className="task-actions">
          {editing ? (
            <>
              <button className="action-btn save-btn" onClick={handleEdit} disabled={busy}>
                {busy ? "…" : "Save"}
              </button>
              <button className="action-btn" onClick={() => { setEditing(false); setDraft(task.content); }}>
                Cancel
              </button>
            </>
          ) : (
            <>
              <button className="action-btn" onClick={() => setEditing(true)} title="Edit">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                </svg>
              </button>
              <button className="action-btn delete-btn" onClick={() => onDelete(task.id)} title="Delete">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="3 6 5 6 21 6"/>
                  <path d="M19 6l-1 14H6L5 6"/>
                  <path d="M10 11v6M14 11v6"/>
                  <path d="M9 6V4h6v2"/>
                </svg>
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
