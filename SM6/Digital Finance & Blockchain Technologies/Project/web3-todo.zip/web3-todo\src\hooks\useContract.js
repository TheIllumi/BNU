import { useState, useCallback } from "react";
import { Contract } from "ethers";
import { CONTRACT_ADDRESS, CONTRACT_ABI } from "../contract.js";

export function useContract(provider, onReceipt) {
  const [tasks, setTasks]       = useState([]);
  const [loading, setLoading]   = useState(false);
  const [txStatus, setTxStatus] = useState(null);
  const [txMsg, setTxMsg]       = useState("");

  const getContract = useCallback(async (write = false) => {
    if (!provider) throw new Error("No provider");
    if (write) {
      const signer = await provider.getSigner();
      return new Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
    }
    return new Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);
  }, [provider]);

  const loadTasks = useCallback(async () => {
    try {
      setLoading(true);
      const contract = await getContract(false);
      const ids = await contract.getMyTasks();
      const fetched = await Promise.all(
        ids.map(async (id) => {
          const [content, isCompleted, owner] = await contract.getTask(id);
          return { id: id.toString(), content, isCompleted, owner };
        })
      );
      setTasks(fetched.reverse());
    } catch (e) {
      console.error("loadTasks:", e);
    } finally {
      setLoading(false);
    }
  }, [getContract]);

  const withTx = useCallback(async (fn, successMsg) => {
    try {
      setTxStatus("pending");
      setTxMsg("Waiting for confirmation…");
      const tx = await fn();
      const receipt = await tx.wait();
      if (onReceipt) onReceipt(receipt);
      setTxStatus("success");
      setTxMsg(successMsg);
      await loadTasks();
      setTimeout(() => setTxStatus(null), 3500);
    } catch (e) {
      setTxStatus("error");
      setTxMsg(e?.reason || e?.message || "Transaction failed");
      setTimeout(() => setTxStatus(null), 4000);
    }
  }, [loadTasks, onReceipt]);

  const createTask = useCallback(async (content) => {
    const contract = await getContract(true);
    await withTx(() => contract.createTask(content), "Task created on-chain ✓");
  }, [getContract, withTx]);

  const toggleTask = useCallback(async (id) => {
    const contract = await getContract(true);
    await withTx(() => contract.toggleTask(id), "Task toggled ✓");
  }, [getContract, withTx]);

  const editTask = useCallback(async (id, newContent) => {
    const contract = await getContract(true);
    await withTx(() => contract.editTask(id, newContent), "Task updated ✓");
  }, [getContract, withTx]);

  const deleteTask = useCallback(async (id) => {
    const contract = await getContract(true);
    await withTx(() => contract.deleteTask(id), "Task deleted ✓");
  }, [getContract, withTx]);

  return { tasks, loading, txStatus, txMsg, loadTasks, createTask, toggleTask, editTask, deleteTask };
}
